/* Added for Tor. */
#include "torint.h"
#define crypto_uint32 uint32_t
